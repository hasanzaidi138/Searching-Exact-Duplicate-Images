hash_file = 'img_hashes_%s.csv' % 16
print(hash_file)
